#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
sleep 5
chmod 777 /sys/class/power_supply/main/current_max
chmod 777 /sys/class/power_supply/main/constant_charge_current_max
chmod 777 /sys/class/power_supply/battery/constant_charge_current
chmod 777 /sys/class/power_supply/battery/constant_charge_current_max
chmod 777 /sys/class/power_supply/usb/current_max
chmod 777 /sys/class/power_supply/usb/hw_current_max
chmod 777 /sys/class/power_supply/usb/pd_current_max
chmod 777 /sys/class/power_supply/usb/ctm_current_max
while true; do
echo '1' > /sys/kernel/fast_charge/force_fast_charge
echo '0' > /sys/class/power_supply/battery/step_charging_enabled
echo '0' > /sys/class/power_supply/battery/sw_jeita_enabled
echo '3200000' > /sys/class/power_supply/main/current_max
echo '5100000' > /sys/class/power_supply/main/constant_charge_current_max
echo '5100000' > /sys/class/power_supply/battery/constant_charge_current
echo '5100000' > /sys/class/power_supply/battery/constant_charge_current_max
echo '3200000' > /sys/class/power_supply/usb/current_max
echo '3200000' > /sys/class/power_supply/usb/hw_current_max
echo '3200000' > /sys/class/power_supply/usb/pd_current_max
echo '3200000' > /sys/class/power_supply/usb/ctm_current_max
sleep 1
done