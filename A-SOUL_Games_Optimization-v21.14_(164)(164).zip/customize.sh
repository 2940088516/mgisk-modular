if [ -d /data/adb/modules/unity_affinity_opt ]; then
    mv /data/adb/modules/unity_affinity_opt /data/adb/modules/asoul_affinity_opt
fi
rm -rf /data/adb/asopt

ui_print "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
ui_print "    安装此模块前卸载CuToolbox，你不卸载我帮你卸载"
ui_print "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/AsoulOpt 0 0 0755 0755
