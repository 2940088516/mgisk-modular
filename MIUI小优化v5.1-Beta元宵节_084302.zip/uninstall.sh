#!/system/bin/sh
uninstall_recover() {
  rm -rf $1
  touch $1
  chmod 644 $1
}

if [[ -d /data/adb/modules/sdcardfs_y ]]; then
  touch /data/adb/modules/sdcardfs_y/remove
fi

if [[ -d /data/adb/modules/fstrim_y ]]; then 
  rm -rf /data/adb/modules/fstrim_y
fi

if [[ -e /data/user_de/0/com.miui.home/cache/debug_log ]]; then
  uninstall_recover /data/user_de/0/com.miui.home/cache/debug_log
fi

if [[ -e /data/vendor/wlan_logs ]]; then
  uninstall_recover /data/vendor/wlan_logs
fi

if [[ -e /data/media/0/JuphoonService ]]; then
  uninstall_recover /data/media/0/JuphoonService
fi


