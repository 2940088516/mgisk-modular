mount -o rw,remount /
mount -o rw,remount /system
mount -o rw,remount /vendor
sed -i '/ro.surface_flinger.max_frame_buffer_acquired_buffers/d' /system/build.prop
sed -i '/ro.surface_flinger.vsync_event_phase_offset_ns/d' /system/build.prop
sed -i '/ro.surface_flinger.vsync_sf_event_phase_offset_ns/d' /system/build.prop
sed -i '/# ro.surface_flinger.present_time_offset_from_vsync_ns/d' /system/build.prop
sed -i '/debug.sf.disable_backpressure/d'  /system/build.prop
sed -i '/debug.sf.latch_unsignaled=1/d'  /system/build.prop