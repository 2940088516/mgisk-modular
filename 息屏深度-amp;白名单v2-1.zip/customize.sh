SKIPUNZIP=0
REPLACE="
"
if [[ `find /data/app -name "com.kmou424.ToastCreator*" -type d` ]]; then
echo " * 已存在Toast依赖"
rm -rf $MODPATH/toast.apk
else
echo " * 正在安装ToastCreator"
echo " * Toast插件來自kmou424"
pm install -r -g $MODPATH/toast.apk >/dev/null 2>&1
 if [[ $? = 0 ]]; then
   echo " * 安裝成功"
 else
   echo " * 安裝失败"
 fi
rm -rf $MODPATH/toast.apk
fi

echo "****************************"
echo ""
echo "  正在创建白名单   "
echo "Path:/Android/doze.conf"
cat $MODPATH/doze.conf > /storage/emulated/0/Android/doze.conf

if [[ $? = 0 ]]; then
echo "******************"
echo "      安装完成    "
echo "******************"
else
echo "******************"
echo "      安装失败    "
echo "******************"
fi
