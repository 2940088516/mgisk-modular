#!/system/bin/sh
export TZ=Asia/Shanghai
Log() {
  am start -n com.kmou424.ToastCreator/com.kmou424.ToastCreator.MainActivity --es msg "$1" >/dev/null 2>&1
  LogTxt "$1"
  
}
LogTxt(){
  txt="/sdcard/Android/doze.log"
  echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> $txt
}