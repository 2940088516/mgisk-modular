#!/system/bin/sh
source /data/adb/modules/dozewhitelist/log.sh

#执行移出电池优化名单
noDozes=$(cat /sdcard/Android/doze.conf)
noDozes=`pm list packages -e | sed "s/package:/-/g"`$noDozes
dumpsys deviceidle whitelist $noDozes
LogTxt "执行清理电池优化名单，应用白名单"


