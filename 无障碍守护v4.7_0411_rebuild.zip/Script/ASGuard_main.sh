#!/system/bin/sh
DIR=$1
path=/data/media/0/Android
data=$1/config/EAS.ini
proppath=$1/module.prop
sc=$1/config

echo "[$(date "+%H:%M:%S")]: ASGuard Running" >> $path/log_ASG.txt

#加入电池优化白名单
add_whitelist() {
  if [[ "$1" != "" ]];then
    echo "[$(date "+%H:%M:%S")] [Whitelist]: Adding Whitelist <="$1 >> $path/log_ASG.txt
    dumpsys deviceidle whitelist +$1
  elif [[ "$AS" != "" ]];then
    echo "[$(date "+%H:%M:%S")] [Whitelist]: Adding Whitelist <="$AS >> $path/log_ASG.txt
    array=(${AS// / })
    for var in ${array[@]}
    do
      dumpsys deviceidle whitelist +$var
    done
  fi
  exit
}

#记录运行时间
mark_time() {
  timer_end=`date "+%Y-%m-%d %H:%M:%S"`
  duration=`echo $(($(date +%s -d "${timer_end}") - $(date +%s -d "${timer_start}"))) | awk '{t=split("60 s 60 m 24 h 999 d",a);for(n=1;n<t;n+=2){if($1==0)break;s=$1%a[n]a[n+1]s;$1=int($1/a[n])}print s}'`
  sed -i "s#^description=.*#description=开机自动开启且实时保护无障碍服务(辅助功能)，防止应用意外关闭导致无障碍服务连同关闭 [本次截至"$(date "+%H:%M:%S")"已运行:"$duration"]#g" $proppath
}

#读用户配置
read_AS() {
  #版本遗留，暂无需求，姑且存放
  #touch $path/ASGuard.txt
  . $path/ASGuard.conf
  if [[ $AS != "" ]];then
    running=1
    #touch $sc/enabled
    #[[ -f $sc/disabled ]] && rm $sc/disabled
  else
    running=2
    #touch $sc/disabled
    #[[ -f $sc/enabled ]] && rm $sc/enabled
  fi
}

#读EAS.ini，空则将开关写入
read_EAS() {
  touch $data
  EAS=$(sed -n p $data)
  if [[ $EAS != "" ]];then
    running_2=1
  else
    if [[ "$AS" != "" ]];then
      local dp1
      dp1=(${EAST//:/ })
      local dp2
      dp2=(${AS// / })
      local tmp=""
      for var1 in ${dp1[@]}
      do
        for var2 in ${dp2[@]}
        do
          result=$(echo $var1 | grep "$var2/")
          if [[ "$result" != "" ]];then
            #写入格式保持一致
            #淦它凉的Android R！hetui！
            var=(${var1//'/'/ })
            result=$(echo ${var[1]} | grep $var2)
            if [[ "$result" = "" ]];then
              tmp="$tmp${var2}/${var2}${var[1]}\n"
            else
              tmp="$tmp$var1\n"
            fi
            unset var
            break
          fi
        done
      done
      if [[ "$tmp" != "" ]];then
        echo -e "$tmp" > $data
        echo "[$(date "+%H:%M:%S")] [ASGuard]: EAS.ini Rebuild" >> $path/log_ASG.txt
        running_2=2
      else
        running_2=0
      fi
    fi
    running_2=0
  fi
}

#读、写无障碍服务开关
read_EAST() {
  EAST=$(settings get secure enabled_accessibility_services)
}
write_EAST() {
  settings put secure enabled_accessibility_services $1
}

if_AS() {
  #用户配置是否发生改变
  if [[ "$old_AS" != "$AS" ]];then
    old_AS=$(echo "$old_AS" | sort | uniq)
    AS=$(echo "$AS" | sort | uniq)
    local dp1
    local dp2
    local dp3
    local tmp
    local tmpAS
    local EAS
    local tmpEAST
    local var
    local varvar
    
    #取用户配置增加项，减少项不处理因此不写
    tmp=$(echo -e "$AS\n$old_AS" | sort | uniq -d)
    tmpAS=$(echo -e "$AS\n$tmp" | sort | uniq -u)
    tmp=""
    #判断有无增加的配置
    if [[ "$tmpAS" = "" ]];then
      echo "[$(date "+%H:%M:%S")] [ASGuard]: ASGuard.conf AS_list:Decrease" >> $path/log_ASG.txt
      #测试用return
      #return 0
      exit
    else
      echo "[$(date "+%H:%M:%S")] [ASGuard]: ASGuard.conf AS_list:Changed" >> $path/log_ASG.txt
    fi
    #新增的配置项从EAS.ini取名称
    dp1=(${tmpAS// / })
    dp2=(${EAS// / })
    for var1 in ${dp1[@]}
    do
      add_whitelist $var1 &
      for var2 in ${dp2[@]}
      do
        result=$(echo $var2 | grep "$var1/")
        if [[ "$result" != "" ]];then
          varvar=$(var2//"$var1"/ })
          result=$(echo "$EAST:" | grep "${varvar[1]}:")
          if [[ "$result" = "" ]];then
            #tmp为待开启开关的名称
            tmp="$tmp:$var2"
            echo "[$(date "+%H:%M:%S")] [ASGuard]: Start '$var2'" >> $path/log_ASG.txt
            am startservice -n $var2
          fi
        fi
      done
      #如果EAS.ini有此循环配置的开关名称，则打开开关，否则从开关里面找并写到EAS.ini
      if [[ "$tmp" != "" ]];then
        tmpEAST=$tmpEAST$tmp
        tmp=""
      else
        dp3=(${EAST//:/ })
        for var3 in ${dp3[@]}
        do
          result=$(echo $var3 | grep "$var1/")
          if [[ "$result" != "" ]];then
            var=(${var3//'/'/ })
            result=$(echo ${var[1]} | grep ${var[0]})
            if [[ "$result" = "" ]];then
              tmpEAS="$tmpEAS${var[0]}/${var[0]}${var[1]}\n"
              echo "[$(date "+%H:%M:%S")] [ASGuard]: Mark '${var[0]}/${var[0]}${var[1]}' into EAS.ini" >> $path/log_ASG.txt
            else
              tmpEAS="$tmpEAS$var3\n"
              echo "[$(date "+%H:%M:%S")] [ASGuard]: Mark '$var3' into EAS.ini" >> $path/log_ASG.txt
            fi
          fi
        done
      fi
    done
    if [[ "$tmpEAS" != "" ]];then
      EAS=$(echo -e "$EAS$tmpEAS\n")
      echo -e "$EAS" > $data
    fi
    if [[ "$tmpEAST" != "" ]];then
      #再读一遍防止其他线程的处理被旧数据覆盖
      read_EAST
      write_EAST $EAST$tmpEAST
    fi
  fi
  exit
}

increase_EAST() {
  #取新增的开关，EAST减old_EAST
  local dp1
  local dp2
  local logo=0
  local tmpEAS
  local var
  local tmp
  local iEAST
  #取用户配置增加项，减少项不处理因此不写
  tmp=$(echo -e "$EAST\n$old_EAST" | sort | uniq -d)
  iEAST=$(echo -e "$EAST\n$tmp" | sort | uniq -u)
  dp1=(${iEAST// / })
  for var1 in ${dp1[@]}
  do
    #检查是否为用户配置的，是则写入EAS.ini
    dp2=(${AS// / })
    for var2 in ${dp2[@]}
    do
      #判断是否为用户配置APP的开关
      result=$(echo $var1 | grep "$var2/")
      if [[ "$result" != "" ]];then
        #分隔判断，EAS为完整内容，EAST不一定完整
        var=(${var1//'/'/ })
        result=$(echo $EAS" " | grep "${var1[1]} ")
        if [[ "$result" = "" ]];then
          #判断精简，补全写入
          result=$(echo ${var[1]} | grep $var2)
          if [[ "$result" = "" ]];then
            tmpEAS="$tmpEAS$var2/$var2${var[1]}\n"
          else
            tmpEAS="$tmpEAS$var1\n"
          fi
          break
        fi
      fi
    done
  done
  #不为空则写入
  if [[ "$tmpEAS" != "" ]];then
    read_EAS
    EAS="$EAS\n$tmpEAS"
    echo -e "$EAS" > $data
    echo "[$(date "+%H:%M:%S")] [ASGuard]: EAST increase and mark'"$tmpEAS"'" >> $path/log_ASG.txt
  fi
  exit
}
decrease_EAST() {
  local dp1
  local dp2
  local var
  local tmp
  local tmpEAST
  #取减少的开关的名称
  tmp=$(echo -e "$EAST\n$old_EAST" | sort | uniq -d)
  dEAST=$(echo -e "$old_EAST\n$tmp" | sort | uniq -u)
  tmp=""
  dp1=(${dEAST// / })
  for var1 in ${dp1[@]}
  do
    #判断是否为用户配置的，是则写入
    dp2=(${AS// / })
    for var2 in ${dp2[@]}
    do
      result=$(echo $var1 | grep "$var2/")
      #判断是否为用户配置的APP开关
      if [[ "$result" != "" ]];then
        add_whitelist $var2 &
        var=(${var1//'/'/ })
        #判断开关是否已经存在（重复）
        result=$(echo $EAST" " | grep "${var[1]} ")
        if [[ "$result" = "" ]];then
          result=$(echo "$tmpEAST:" | grep "${var[1]}:")
          if [[ "$result" = "" ]];then
            #启动服务，开关先记录下来最后一起打开
            tmpEAST="$tmpEAST:$var1"
            am startservice -n "$var1"
            break
          fi
        fi
      fi
    done
  done
  if [[ $tmpEAST != "" ]];then
    #防止其它线程处理的数据无效，因此写入前再读一次
    read_EAST
    write_EAST $EAST$tmpEAST
    echo "[$(date "+%H:%M:%S")] [ASGuard]: Protect '$tmpEAST'" >> $path/log_ASG.txt
  fi
  exit
}

read_AS
read_EAST
read_EAS
old_AS=$AS
old_EAST=$EAST
switch=1
if [[ "$2" = "1" ]];then
  if ((running != 0));then
    add_whitelist &
  else
    echo "[$(date "+%H:%M:%S")] [ASGuard.txt]: No pacakge to add whitelist" >> $path/log_ASG.txt
  fi
fi

#大循环
until ((running > 5))
do
  #模块开关打开则运行
  if [[ ! -f $DIR/disable ]];then
    #标记变量，确保在此分支连续多次运行只运行一次
    if [[ $switch = 0 ]];then
      switch=1
      sed -i "s#^description=.*#description=开机自动开启且实时保护无障碍服务(辅助功能)，防止应用意外关闭导致无障碍服务连同关闭#g" $proppath
      sh $DIR/Script/ASGuard_start.sh $DIR 1 &
      exit
    fi
    timer_start=`date "+%Y-%m-%d %H:%M:%S"`
    read_AS
    until ((running != 1))
    do
      #标记变量，确保在此分支连续运行多次只输出一次log
      if [[ $tip != 1 ]];then
        echo "[$(date "+%H:%M:%S")] [ASGuard]: Service running" >> $path/log_ASG.txt
        tip=1
      fi
      read_AS
      read_EAS
      read_EAST
      if_AS &
      #记录模块运行时间，关闭可在“mark_time &”前面加"#"注释掉
      #开启只需删去添加的"#"即可
      mark_time &
      if [[ $old_EAST != $EAST ]];then
        EAST=$(echo "$EAST" | sed "s/:/\n/g" | sort | uniq)
        old_EAST=$(echo "$old_EAST" | sed "s/:/\n/g" | sort | uniq)
        increase_EAST &
        decrease_EAST &
      fi
      wait
      #上面更改过EAST需要再读一次
      read_EAST
      old_EAST="$EAST"
      old_AS="$AS"
      sleep 3
      [[ -f $DIR/disable ]] && running=0
    done
    if [[ $tip = 1 ]];then
      echo "[$(date "+%H:%M:%S")] [ASGuard]: Service stop" >> $path/log_ASG.txt
      tip=0
    fi
    sleep 9
  else
    if [[ $switch = 1 ]];then
      sed -i "s#^description=.*#description=开机自动开启且实时保护无障碍服务(辅助功能)，防止应用意外关闭导致无障碍服务连同关闭 [已被手动停止]#g" $proppath
      switch=0
    fi
    sleep 9
  fi
done
exit 0