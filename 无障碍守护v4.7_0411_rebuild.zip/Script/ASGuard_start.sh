#!/system/bin/sh
input=$1
reload=$2
path=/data/media/0/Android
inform="ASGuard v4.7_0411_rebuild(20210410) by 沍澤"
data=$input/config/EAS.ini
proppath=$input/module.prop
switch=$input/config
MODPATH=$input/Script/ASGuard_main.sh

#加入电池优化白名单
add_whitelist() {
  if [[ "$AS" != "" ]];then
    local dp1
    dp1=(${AS// / })
    for var1 in ${dp1[@]}
    do
      dumpsys deviceidle whitelist +$var1
    done
  fi
  if [[ "$package_whitelist" != "" ]];then
    local dp2
    dp2=(${package_whitelist// / })
    for var2 in ${dp2[@]}
    do
      dumpsys deviceidle whitelist +$var2
    done
  fi
}

#读用户配置包名
read_AS() {
  #之前版本遗留，目前暂不需要，但先留着
  #touch $path/ASGuard.txt
  . $path/ASGuard.conf
  if [[ $AS != "" ]];then
    running=1
    #touch $switch/enabled
    #[[ -f $switch/disabled ]] && rm $switch/disabled
  else
    running=0
    #touch $switch/disabled
    #[[ -f $switch/enabled ]] && rm $switch/enabled
  fi
}
#读EAS.ini，空则创建写入
read_EAS() {
  local tmp
  #文件是否存在
  touch $data
  EAS=$(sed -n p $data)
  if [[ "$EAS" != "" ]];then
    running_2=1
  else
    running_2=2
    #判断用户配置是否不为空
    if [[ "$AS" != "" ]];then
      local dp1
      dp1=(${EAST//:/ })
      local dp2
      dp2=(${AS// / })
      local logo=0
      local tmp=""
      for var1 in ${dp1[@]}
      do
        for var2 in ${dp2[@]}
        do
          result=$(echo $var1 | grep $var2)
          if [[ "$result" != "" ]];then
            logo=1
            break
          fi
        done
        if ((logo == 1));then
          #统一写入EAS.ini的格式为xx.xx.xx/xx.xx.xx.yy,yy
          #而不是xx.xx.xx/.yy,yy
          #Android 11针ex 淦！
          var=(${var1//'/'/ })
          result=$(echo ${var[1]} | grep ${var[0]})
          if [[ "$result" = "" ]];then
            tmp="$tmp\n${var[0]}/${var[0]}${var[1]}"
          else
            tmp="$tmp\n$var1"
          fi
          logo=0
        fi
      done
      if [[ "$tmp" != "" ]];then
        echo -e "$tmp" > $data
        EAS=$(echo -e "$tmp")
        echo "[$(date "+%H:%M:%S")]: Saving Enable_Accessible_Services" >> $path/log_ASG.txt
      fi
    fi
  fi
  unset var
}

read_EAST() {
EAST=$(settings get secure enabled_accessibility_services)
}

write_EAST() {
settings put secure enabled_accessibility_services $1
}

[[ $reload != 1 ]] && Running_time=`date "+%Y-%m-%d %H:%M:%S"`

#等待开机完成以防文件写入失败
if [ -f $path/log_ASG.txt ];then
  file=1
  until ((file == 0))
  do
    rm $path/log_ASG.txt
    if [ -f $path/log_ASG.txt ];then
      sleep 4
    else
      file=0
    fi
  done
  echo $inform > $path/log_ASG.txt
else
  file=0
  until ((file == 1))
  do
    echo $inform > $path/log_ASG.txt
    if [ -f $path/log_ASG.txt ];then
      file=1
    else
      sleep 4
    fi
  done
fi

echo "Running Date $(date "+%y.%m.%d")" >> $path/log_ASG.txt
#if [[ $reload != 1 ]];then
#  if [[ -f $input/updata ]];then
#更新模块后需要执行的命令，目前还没有先放着
#    rm $input/updata
#  fi
#fi
if [[ $reload != 1 ]];then
  echo "[$(date "+%H:%M:%S")]: Config Loading" >> $path/log_ASG.txt
else
  echo "[$(date "+%H:%M:%S")]: Config Reloading" >> $path/log_ASG.txt
fi
settings put secure accessibility_enabled 1
sleep 1

sed -i "s#^description=.*#description=开机自动开启且实时保护无障碍服务(辅助功能)，防止应用意外关闭导致无障碍服务连同关闭 [正在运行]#g" $proppath

#读取配置
read_AS
if [[ $reload != 1 ]];then
  echo "[$(date "+%H:%M:%S")]: Loading AS:"$AS >> $path/log_ASG.txt
else
  echo "[$(date "+%H:%M:%S")]: Reloading AS:"$AS >> $path/log_ASG.txt
fi
read_EAST
read_EAS
echo "[$(date "+%H:%M:%S")]: Checking EAS.ini" >> $path/log_ASG.txt

#检查和去除EAS.ini重复的名称并重新写入#
tmp=""
dp=(${EAS// / })
for var in ${dp[@]}
do
  local varvar
  varvar=(${var//'/'/ })
  result=$(echo $tmp | grep "${varvar[1]}:")
  if [[ "$result" = "" ]];then
    result=$(echo ${varvar[1]} | grep ${varvar[0]})
    if [[ "$result" = "" ]];then
      tmp="$tmp${varvar[0]}/${varvar[0]}${varvar[1]}\n"
    else
      tmp="$tmp$var\n"
    fi
  fi
done
echo -e "$tmp" > $data
unset dp
unset var
unset tmp

#更改数据重新读取
read_EAS

tmpEAST=""
tmpEAS=""
tmpAS=""
tmp=""

#分隔文本
local dp1
dp1=(${EAS// / })
local dp2
dp2=(${AS// / })
##进度到此
echo "[$(date "+%H:%M:%S")]: Starting Services" >> $path/log_ASG.txt

#把EAS.ini保存的用户配置的名称选出来同时启动服务，并检查开关是否已经存在，存在则放在后面写入
for var1 in ${dp1[@]}
do
    for var2 in ${dp2[@]}
    do
      #从EAS.ini中取用户配置项的开关
      result=$(echo $var1 | grep $var2)
      if [[ "$result" != "" ]];then
        am startservice -n $var1
        tmp="$tmp:$var1"
        break
      fi
    done
done
if [[ "$tmp" != "" ]];then
  sleep 1
  write_EAST $tmp
  echo "[$(date "+%H:%M:%S")]: Turned on AccessibilityServices" >> $path/log_ASG.txt
  tmp=""
fi

#前面更改数据现在读取
read_EAST

#初始化大致完成
Ending_time=`date "+%Y-%m-%d %H:%M:%S"`
duration=`echo $(($(date +%s -d "${Ending_time}") - $(date +%s -d "${Running_time}"))) | awk '{t=split("60 s 60 m 24 h 999 d",a);for(n=1;n<t;n+=2){if($1==0)break;s=$1%a[n]a[n+1]s;$1=int($1/a[n])}print s}'`
[[ "$duration" = "" ]] && duration="0s"
echo "[$(date "+%H:%M:%S")]: Initialization completed. It took "$duration >> $path/log_ASG.txt
unset dp
unset dp1
unset dp2
unset tmpAS
unset tmpEAS
unset tmpEAST
unset tmp
unset Running_time
unset Ending_time
unset reload
unset var
unset var1
unset var2

sh $MODPATH $input $reload &
if ((reload != 1));then
  sleep 60
  echo "[$(date "+%H:%M:%S")] [Whitelist]: Clearing Default_Whitelist " >> $path/log_ASG.txt
  #别问，问就是直接复制的阿巴阿巴酱的清空电池优化白名单😂此段代码写入已在群里@当事人并告知👋🐟
  ## 这段for循环可以不产生额外文件而进行电池优化，感谢酷安@落叶凄凉TEL老哥提供的方法。
  app=$(pm list packages --user 0 | sed 's/package://g')
  for line in $app; do
  dumpsys deviceidle whitelist -$line >/dev/null 2>&1
  done
  echo "[$(date "+%H:%M:%S")] [Whitelist]: Adding Whitelist " >> $path/log_ASG.txt
  add_whitelist
fi
exit 0