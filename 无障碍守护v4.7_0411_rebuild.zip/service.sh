#!/system/bin/sh
# 请不要硬编码 /magisk/modname/... ; 请使用 $MODDIR/...
# 这将使你的脚本更加兼容 即使Magisk在未来改变了它的挂载点
MODDIR=${0%/*}
chmod 7777 $MODDIR/Script/ASGuard_main.sh
chmod 7777 $MODDIR/Script/ASGuard_start.sh

PROCESS1()
{
ps -ef | grep "ASGuard_start.sh" | grep -v grep | wc -l
}

PROCESS2()
{
ps -ef | grep "ASGuard_main.sh" | grep -v grep | wc -l
}

until [[ "$(PROCESS1)" != "0" ]] || [[ "$(PROCESS2)" != "0" ]]
do
  nohup sh $MODDIR/Script/ASGuard_start.sh $MODDIR 0 &
  sleep 2
done
exit