#!/system/bin/sh

#安装脚本

#默认不动
SKIPMOUNT=false
#如果想启用system.prop的参数，则改为true
PROPFILE=false
#开机前执行的命令，想启用则改为true
POSTFSDATA=false
#开机后执行的命令，想启用则改为true
LATESTARTSERVICE=false
echo "欢迎使用k30pro双扬声器调教版"
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
echo "精简无用代码，开机与APP启动速度更快"
echo "单独提高整体音量，使最大音量更大"
echo "替换小部分代码，融入低音音效"
echo "搞定"
echo "记得安装恬柒的哈曼卡顿音效与VIPerfx模块哦🙄"
echo "好用记得去酷安给恬柒点个赞"
chmod 755 $MODPATH