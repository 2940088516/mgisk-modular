#!/system/bin/sh
MODDIR=${0%/*}

while :; do
	if [[ $(dumpsys window policy | grep "mInputRestricted" | cut -d= -f2) != "true" ]]; then
#		if [[ ! -f /sdcard/Android/FUCK-XXX.conf ]]; then
#			sed -i "/^description=/c description=！[ /sdcard/Android/FUCK-XXX.conf ] 文件不存在，停止运行。" "$MODDIR/module.prop"
#			touch $MODDIR/disable
#			exit 1
#		fi

		rm_fuck="$(ls /data/media/0/*/fuck 2>/dev/null)"
		rm_fuck_a="$(ls /data/media/0/*/*/fuck 2>/dev/null)"
		for fuck in $rm_fuck $rm_fuck_a; do
			[[ -f $fuck ]] && (sed -i "/SelfDefinition=\"/a${fuck%/fuck}/ #手动添加" "/sdcard/Android/FUCK-XXX.conf")
		done

		source /sdcard/Android/FUCK-XXX.conf
#		if [[ $? != 0 ]]; then
#			sed -i "/^description=/c description=提示：规则文件读取有误，不要在 “ ” 之外填写任何中英文字符！请检查并修改保存后再重新打开模块运行。（无需重启）" "$MODDIR/module.prop"
#			touch $MODDIR/disable
#			exit 2
#		fi

		tmp="$MODDIR/files/$(date "+%Y-%m-%d")"
		if [[ ! -d $tmp ]]; then
			rm -rf $MODDIR/files/*/ >/dev/null 2>&1
			mkdir -p $tmp
			echo 0 > $tmp/dir
			echo 0 > $tmp/file
		fi

		for i in $sdcard $Download $Android $SelfDefinition; do
			if [[ -d $i ]]; then
				case $i in
				"/data"|"/data/"|"/data/media/0"|"/data/media/0/"|"/data/media/0/Downloa"|"/data/media/0/Download/"|"/data/media/0/Android"|"/data/media/0/Android/"|"/sdcard"|"/sdcard/"|"/sdcard/Download"|"/sdcard/Download/"|"/sdcard/Android"|"/sdcard/Android/"|"/storage"|"/storage/"|"/storage/emulated/0"|"/storage/emulated/0/"|"/storage/emulated/0/Download"|"/storage/emulated/0/Download/"|"/storage/emulated/0/Android"|"/storage/emulated/0/Android/"|"/"|"/*")  (sed -i "/^description=/c description=！警告: 你填写了 $i ，触发停止运行！请删除后再打开模块继续运行！（无需重启）" "$MODDIR/module.prop" ; touch $MODDIR/disable ; exit 3 ) ;;
				*)  (rm -rf $i ; dir1=`cat $tmp/dir` ; dir2=$(expr $dir1 + 1) ; echo $dir2 > $tmp/dir ) ;;
				esac
			fi
			if [[ -f $i ]]; then
				rm -rf $i ; file1=`cat $tmp/file` ; file2=$(expr $file1 + 1) ; echo $file2 > $tmp/file
			fi
		done

		DIR=`cat $tmp/dir`
		FILE=`cat $tmp/file`
		sed -i "/^description=/c description=总有到处乱拉屎的文件/文件夹？吔屎啦雷！[ 今日已吃掉: $FILE个垃圾文件 $DIR个垃圾文件夹 ]" "$MODDIR/module.prop"
	fi
	sleep 10
done
