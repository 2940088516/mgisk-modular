SKIPUNZIP=0

get_choose()
{
	local choose
	local branch
	while :; do
		choose="$(getevent -qlc 1 | awk '{ print $3 }')"
		case "$choose" in
		KEY_VOLUMEUP)  branch="0" ;;
		KEY_VOLUMEDOWN)  branch="1" ;;
		*)  continue ;;
		esac
		echo "$branch"
		break
	done
}

MyPrint() 
{
	echo "$@"
	sleep 0.03
}

MyPrint "------------------------------------------------------------------------------------------------------------------------------------------------------------------------"
MyPrint "(&) v3.1.2更新内容:"
MyPrint "- ① 修复已知bug"
MyPrint " "
MyPrint "(&) v3.1.1更新内容:"
MyPrint "- ① 同步搞机助手云端"
MyPrint " "
MyPrint "(&) v3.1.0更新内容:"
MyPrint "- ① 解决部分设备规则文件正常而重启后运行异常的问题"
MyPrint "- ② 优化shell命令"
MyPrint " "
MyPrint "(&) v3.0更新内容:"
MyPrint "- ① 新增:在/sdcard/文件夹或/sdcard/文件夹/文件夹 中添加fuck文件 自动将该路径添加至规则文件中"
MyPrint "- ② 新增:刷入时旧规则文件是否保留可自行选择 不再强制替换"
MyPrint " "
MyPrint "(&) v2.3更新内容: "
MyPrint "- ① 修复重启后部分设备错误提示无法运行问题"
MyPrint " "
MyPrint "(&) v2.2.1更新内容："
MyPrint "- ① 新增:读取规则文件有误时提示(显示在模块介绍)"
MyPrint "- ② 补充:规则文件说明内容 防止不必要的问题出现"
MyPrint "- ③ 优化:shell命令"
MyPrint "- ④ 模块名称重命名:A-循环吃掉乱拉屎的文件/文件夹"
MyPrint " "
MyPrint "(√) 当前模块功能概述："
MyPrint "- [1] 每隔10秒删除填写在规则文件.conf内的路径"
MyPrint "- [2] 只在亮屏时执行 息屏不做处理"
MyPrint "- [3] 误填路径(/data /sdcard /sdcard/Download ..等重要路径)保存，立即停止运行并自动关闭模块给出提示"
MyPrint "- [4] 在 /sdcard/文件夹 或 /sdcard/文件夹/文件夹 添加fuck文件会自动帮你填写进规则文件中并删除该文件夹"
MyPrint "- [5] 编不下去了.."
MyPrint "------------------------------------------------------------------------------------------------------------------------------------------------------------------------"
MyPrint " "
MyPrint "(!) 安装说明："
MyPrint "- 安装完成重启后将默认删除/sdcard目录所有以.开头的文件夹/文件 以及其他无用文件夹"
MyPrint "- 先确认没有重要资料保存在/sdcard目录的以.开头的文件夹中 如果有请先备份后再安装刷入"
MyPrint " "
MyPrint "(?) 确认安装吗？(请选择)"
MyPrint "- 按音量键＋: 安装 √"
MyPrint "- 按音量键－: 退出 ×"
if [[ $(get_choose) == 0 ]]; then
	MyPrint "- 已选择安装"
	MyPrint " "
	if [[ -f /sdcard/Android/FUCK-XXX.conf ]]; then
		MyPrint "- 存在旧规则文件 是否保留原规则文件？(请选择)"
		MyPrint "- 按音量键＋: 保留"
		MyPrint "- 按音量键－: 替换"
		if [[ $(get_choose) == 1 ]]; then
			MyPrint "- 已选择替换备份原规则文件"
			cat /sdcard/Android/FUCK-XXX.conf > "/sdcard/Android/$(date "+%T")备份-FUCK-XXX.conf"
			MyPrint "- 已备份保存至/sdcard/Android/$(date "+%T")备份-FUCK-XXX.conf"
			rm -rf /sdcard/Android/FUCK-XXX.conf
			MyPrint "- 删除旧文件"
			cp -af $MODPATH/files/FUCK-XXX.conf /sdcard/Android/
			MyPrint "- 创建新文件"
			MyPrint " "
		else
			MyPrint "- 已选择保留原规则文件"
			MyPrint " "
		fi
	else
		MyPrint "- 创建规则文件至/sdcard/Android/ 重启后请打开该目录查看FUCK-XXX.conf"
		MyPrint " "
		cp -af $MODPATH/files/FUCK-XXX.conf /sdcard/Android/
	fi
	if [[ -d /data/adb/modules/FUCK-SHIT-FILE/files/*/ ]]; then
		MyPrint "- 存在次数记录信息"
		cp -af /data/adb/modules/FUCK-SHIT-FILE/files/*/ $MODPATH/files/
		MyPrint "- 复制信息"
		MyPrint " "
	fi
	if [[ "$(pm list package | grep -w 'com.coolapk.market')" != "" ]];then
		MyPrint "- 你安装了酷安 是否前往作者主页？(请选择)"
		MyPrint "- 按音量键＋: “前往”"
		MyPrint "- 按音量键－: “爷不去”"
		if [[ $(get_choose) == 0 ]]; then
			am start -d 'coolmarket://u/1132618' >/dev/null 2>&1
			MyPrint "- 已完成"
			MyPrint " "
		else
			MyPrint "- 作者: “尼玛 我记住你了嗷”"
			MyPrint " "
		fi
	fi
else
	abort "- 已选择退出"
fi
