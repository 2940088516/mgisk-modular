##########################################################################################
#
# Magisk Module Template Config Script
#
##########################################################################################
##########################################################################################
#
# Instructions:
#
# 1. Place your files into system folder (delete the placeholder file)
# 2. Fill in your module's info into module.prop
# 3. Configure the settings in this file (config.sh)
# 4. If you need boot scripts, add them into common/post-fs-data.sh or common/service.sh
# 5. Add your additional or modified system properties into common/system.prop
#
##########################################################################################

##########################################################################################
# Configs
##########################################################################################

# Set to true if you need to enable Magic Mount
# Most mods would like it to be enabled
SKIPMOUNT=ture

# Set to true if you need to load system.prop
PROPFILE=false

# Set to true if you need post-fs-data script
POSTFSDATA=ture

# Set to true if you need late_start service script
LATESTARTSERVICE=ture

##########################################################################################
# Installation Message
##########################################################################################

# Set what you want to show when installing your mod

print_modname() {
  ui_print "*******************************"
  ui_print "Mod by wvwvw" 
  ui_print "*******************************"
}

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info about how Magic Mount works, and why you need this

# This is an example
REPLACE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here, it will override the example above
# !DO NOT! remove this if you don't need to replace anything, leave it empty as it is now
REPLACE="
"

##########################################################################################
# Permissions
##########################################################################################
on_install() {
  ui_print "- Extracting module files"
unzip -o "$ZIPFILE" 'module.prop' 'post-fs-data.sh' 'service.sh' 'system/*' -d "$MODPATH"
}
  ui_print "     ✔"

OUTFD="$2"
ZIP="$3"
  ui_print "- Preparing environment"
set_perm() {
	chown $1:$2 $4
	chmod $3 $4
	case $4 in
		*/vendor/etc/*)
			chcon 'u:object_r:vendor_configs_file:s0' $4
		;;
		*/vendor/*)
			chcon 'u:object_r:vendor_file:s0' $4
		;;
		*/data/adb/*.d/*)
			chcon 'u:object_r:adb_data_file:s0' $4
		;;
		*)
			chcon 'u:object_r:system_file:s0' $4
		;;
	esac
}

cp_perm() {
  if [ -f "$4" ]; then
    rm -f $5
    cat $4 > $5
    set_perm $1 $2 $3 $5
  fi
}

set_perm_recursive() {
	find $5 -type d | while read dir; do
		set_perm $1 $2 $3 $dir
	done
	find $5 -type f -o -type l | while read file; do
		set_perm $1 $2 $4 $file
	done
}
  ui_print "     ✔"
  
path_audio() {
if [ -f /$sys_tem/etc/audio_effects.conf ]; then
  ui_print "- Configuring audio effects"
	cp_perm 0 0 0644 $sys_tem/etc/audio_effects.conf /data/adb/modules_update/ViPERFXCN/system/etc/audio_effects.conf
	SYSTEM_CONFIG_MAGISK=/data/adb/modules_update/ViPERFXCN/system/etc/audio_effects.conf
	sed -i "s/^libraries {/libraries {\n  v4a_fx {\n    path \/vendor\/lib\/soundfx\/libv4a_fx.so\n  }/" $SYSTEM_CONFIG_MAGISK
	sed -i "s/^effects {/effects {\n  v4a_standard_fx {\n    library v4a_fx\n    uuid 41d3c987-e6cf-11e3-a88a-11aba5d5c51b\n  }/" $SYSTEM_CONFIG_MAGISK
fi
if [ -f /$sys_tem/vendor/etc/audio_effects.conf ]; then

	cp_perm 0 0 0644 $sys_tem/vendor/etc/audio_effects.conf /data/adb/modules_update/ViPERFXCN/system/vendor/etc/audio_effects.conf
	VENDOR_CONFIG_MAGISK=/data/adb/modules_update/ViPERFXCN/system/vendor/etc/audio_effects.conf
	sed -i "s/^libraries {/libraries {\n  v4a_fx {\n    path \/vendor\/lib\/soundfx\/libv4a_fx.so\n  }/" $VENDOR_CONFIG_MAGISK
	sed -i "s/^effects {/effects {\n  v4a_standard_fx {\n    library v4a_fx\n    uuid 41d3c987-e6cf-11e3-a88a-11aba5d5c51b\n  }/" $VENDOR_CONFIG_MAGISK
fi
if [ -f /$sys_tem/vendor/etc/audio_effects.xml ]; then

	cp_perm 0 0 0644 $sys_tem/vendor/etc/audio_effects.xml /data/adb/modules_update/ViPERFXCN/system/vendor/etc/audio_effects.xml
	VENDOR_MAGISK_XML=/data/adb/modules_update/ViPERFXCN/system/vendor/etc/audio_effects.xml
	sed -i '/<libraries>/ a\        <library name="v4a_fx" path="libv4a_fx.so"\/>' $VENDOR_MAGISK_XML
	sed -i '/<effects>/ a\        <effect name="v4a_standard_fx" library="v4a_fx" uuid="41d3c987-e6cf-11e3-a88a-11aba5d5c51b"\/>' $VENDOR_MAGISK_XML
fi
}
path_audio
  ui_print "     ✔"

  ui_print "- Finalizing module"
set_permissions() {
  # Only some special files require specific permissions
  # The default permissions should be good enough for most cases

  # Here are some examples for the set_perm functions:

  # set_perm_recursive  <dirname>                <owner> <group> <dirpermission> <filepermission> <contexts> (default: u:object_r:system_file:s0)
  # set_perm_recursive  $MODPATH/system/lib       0       0       0755            0644

  # set_perm  <filename>                         <owner> <group> <permission> <contexts> (default: u:object_r:system_file:s0)
  # set_perm  $MODPATH/system/bin/app_process32   0       2000    0755         u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0       2000    0755         u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0       0       0644

  # The following is default permissions, DO NOT remove
  set_perm_recursive  $MODPATH  0  0  0755  0644
  
}
  ui_print "     ✔ Done"
##########################################################################################
# Custom Functions
##########################################################################################

# This file (config.sh) will be sourced by the main flash script after util_functions.sh
# If you need custom logic, please add them here as functions, and call these functions in
# update-binary. Refrain from adding code directly into update-binary, as it will make it
# difficult for you to migrate your modules to newer template versions.
# Make update-binary as clean as possible, try to only do function calls in it.

