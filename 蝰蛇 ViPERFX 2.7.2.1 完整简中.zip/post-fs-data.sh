#!/system/bin/sh

# Switch SELinux to Permissive Mode:

(
  selinux=`getenforce`
  if [ "$selinux" == "Enforcing" ]; then
    setenforce 0 2>/dev/null
  fi
)&

# Kill audioserver PID if it exists already
SERVERPID=$(pidof audioserver)
[ "$SERVERPID" ] && kill $SERVERPID