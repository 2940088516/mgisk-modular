#!/system/bin/sh

(
sleep 3
killall -q audioserver
killall -q mediaserver
)&